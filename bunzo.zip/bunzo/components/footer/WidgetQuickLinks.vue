<template>
    <div class="widget">
        <h4 class="text-white leading-none mb-5 sm:mb-6 md:mb-9">Products</h4>
        <div class="body">
            <ul class=" space-y-4">
                <li>
                    <n-link to="https://smax.ai/en/AI-Agent" class="text-white hover:text-primary">AI Agent</n-link>
                </li>
                <li>
                    <n-link to="https://smax.ai/en/Automation-Builder" class="text-white hover:text-primary">Automation Builder</n-link>
                </li>
                <li>
                    <n-link to="https://smax.ai/en/Multi-channel-Live-chat" class="text-white hover:text-primary">Multi-channel Chat</n-link>
                </li>
                <li>
                    <n-link to="https://smax.ai/en/Web-app-Live-Chat-Widget" class="text-white hover:text-primary">Website Chat</n-link>
                </li>
                <li>
                    <n-link to="https://smax.ai/en/Meta-Ads-Integration" class="text-white hover:text-primary">Meta Ads Optimize</n-link>
                </li>
                <li>
                    <n-link to="https://smax.ai/en/Integration" class="text-white hover:text-primary">Integration</n-link>
                </li>
                <li>
                    <n-link to="hhttps://smax.ai/en/Module-marketplace" class="text-white hover:text-primary">Module marketplace</n-link>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
    export default {
        name: "WidgetQuickLinks"
    };
</script>
