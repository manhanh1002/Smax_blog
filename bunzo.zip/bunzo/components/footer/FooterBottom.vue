<template>
    <div class="bg-secondary-light py-4">
        <div class="container">
            <div class="text-base text-center text-white">
                <p>© 2022 Bunzo Made with <i class="icofont icofont-heart-alt text-red-600"></i> by <a href="#" target="_blank">Codecarnival</a></p>
            </div>
        </div>
    </div>
</template>