<template>
    <div class="newsletter-area">
        <div class="container relative">
            <div class="lg:grid grid-cols-12 py-8 px-[15px] md:p-20 rounded-[10px] bg-primary items-center text-center lg:text-left">
                <div class="col-span-3">
                    <h3 class="text-2xl lg:text-[28px] font-bold mb-7 lg:mb-0 text-white">Subscribe For Newsletter</h3>
                </div>
                <div class="col-span-8 -col-end-1">
                    <form class="sm:flex block">
                        <input type="email" placeholder="Enter your email" required class=" border-2 w-full p-3 rounded-lg bg-transparent focus:border-white focus:outline-none text-white text-lg placeholder:text-white">
                        <button class="bg-white px-5 py-4 font-medium rounded-lg hover:text-white hover:bg-primary-dark transition-all min-w-max ml-0 sm:ml-5 mt-5 sm:mt-0">Subscribe Now</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>