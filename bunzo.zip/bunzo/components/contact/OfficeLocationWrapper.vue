<template>
    <div class="office-location py-section">
        <div class="container">
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="single-office">
                    <div class="bg-[#f4f4f4] rounded-xl p-8">
                        <figure class="text-center relative group">
                            <img src="/images/banners/office-01.png" />
                            <figcaption class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white font-medium border-2 border-white px-10 min-w-max py-3 rounded-lg  group-hover:bg-primary group-hover:text-white">Head Office</figcaption>
                        </figure>
                    </div>
                    <div class="border-2 border-[#f4f4f4] rounded-xl p-8 mt-8">
                        <div class="space-y-5">
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path d="M15.05 5A5 5 0 0 1 19 8.95M15.05 1A9 9 0 0 1 23 8.94m-1 7.98v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                </div>
                                <a href="callto:3594679434" class="hover:text-primary">+88 359 467 9434</a>
                            </div>
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path d="M20 4H4c-1.103 0-2 .897-2 2v12c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V6c0-1.103-.897-2-2-2zm0 2v.511l-8 6.223-8-6.222V6h16zM4 18V9.044l7.386 5.745a.994.994 0 0 0 1.228 0L20 9.044 20.002 18H4z"></path></svg>
                                </div>
                                <a href="mailto:contact@smax.ai" class="hover:text-primary">example@mail.com</a>
                            </div>
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="none" stroke-width="0" viewBox="0 0 24 24" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                                </div>
                                <p>845 Central Ave Hamilton, Ohio(OH), 45011</p>
                            </div>
                        </div>

                        <div class="social mt-8">
                            <h5>Connected with us:</h5>
                            <div class="flex mt-3 space-x-2">
                                <SocialIcon url="https://www.facebook.com/smaxai" icon="icofont-facebook" />
                                <SocialIcon url="https://x.com/GetSmaxAI" icon="icofont-x" />

                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-office">
                    <div class="bg-[#f4f4f4] rounded-xl p-8">
                        <figure class="text-center relative group">
                            <img src="/images/banners/office-02.png" />
                            <figcaption class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white font-medium border-2 border-white px-10 min-w-max py-3 rounded-lg  group-hover:bg-primary group-hover:text-white">USA Office</figcaption>
                        </figure>
                    </div>
                    <div class="border-2 border-[#f4f4f4] rounded-xl p-8 mt-8">
                        <div class="space-y-5">
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path d="M15.05 5A5 5 0 0 1 19 8.95M15.05 1A9 9 0 0 1 23 8.94m-1 7.98v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                </div>
                                <a href="callto:3594679434" class="hover:text-primary">+88 359 467 9434</a>
                            </div>
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path d="M20 4H4c-1.103 0-2 .897-2 2v12c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V6c0-1.103-.897-2-2-2zm0 2v.511l-8 6.223-8-6.222V6h16zM4 18V9.044l7.386 5.745a.994.994 0 0 0 1.228 0L20 9.044 20.002 18H4z"></path></svg>
                                </div>
                                <a href="mailto:contact@smax.ai" class="hover:text-primary">example@mail.com</a>
                            </div>
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="none" stroke-width="0" viewBox="0 0 24 24" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                                </div>
                                <p>845 Central Ave Hamilton, Ohio(OH), 45011</p>
                            </div>
                        </div>

                        <div class="social mt-8">
                            <h5>Connected with us:</h5>
                            <div class="flex mt-3 space-x-2">
                                <SocialIcon url="https://www.facebook.com/smaxai" icon="icofont-facebook" />
                                <SocialIcon url="https://x.com/GetSmaxAI" icon="icofont-x" />
                                <SocialIcon url="https://www.instagram.com" icon="icofont-instagram" />
                                <SocialIcon url="https://www.linkedin.com" icon="icofont-linkedin" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-office">
                    <div class="bg-[#f4f4f4] rounded-xl p-8">
                        <figure class="text-center relative group">
                            <img src="/images/banners/office-03.png" />
                            <figcaption class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white font-medium border-2 border-white px-10 min-w-max py-3 rounded-lg  group-hover:bg-primary group-hover:text-white">Canada Office</figcaption>
                        </figure>
                    </div>
                    <div class="border-2 border-[#f4f4f4] rounded-xl p-8 mt-8">
                        <div class="space-y-5">
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path d="M15.05 5A5 5 0 0 1 19 8.95M15.05 1A9 9 0 0 1 23 8.94m-1 7.98v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                </div>
                                <a href="callto:3594679434" class="hover:text-primary">+88 359 467 9434</a>
                            </div>
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path d="M20 4H4c-1.103 0-2 .897-2 2v12c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V6c0-1.103-.897-2-2-2zm0 2v.511l-8 6.223-8-6.222V6h16zM4 18V9.044l7.386 5.745a.994.994 0 0 0 1.228 0L20 9.044 20.002 18H4z"></path></svg>
                                </div>
                                <a href="mailto:contact@smax.ai" class="hover:text-primary">example@mail.com</a>
                            </div>
                            <div class="flex items-center">
                                <div class="w-12 h-12 flex-shrink-0 rounded-md bg-[#f4f4f4] text-center mr-4 text-heading-light flex justify-center items-center">
                                    <svg stroke="currentColor" fill="none" stroke-width="0" viewBox="0 0 24 24" height="22" width="22" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                                </div>
                                <p>845 Central Ave Hamilton, Ohio(OH), 45011</p>
                            </div>
                        </div>

                        <div class="social mt-8">
                            <h5>Connected with us:</h5>
                            <div class="flex mt-3 space-x-2">
                                <SocialIcon url="https://www.facebook.com/smaxai" icon="icofont-facebook" />
                                <SocialIcon url="https://x.com/GetSmaxAI" icon="icofont-x" />
                                <SocialIcon url="https://www.instagram.com" icon="icofont-instagram" />
                                <SocialIcon url="https://www.linkedin.com" icon="icofont-linkedin" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        components: {
            SocialIcon: () => import("~/components/elements/SocialIcon"),
        },
    };
</script>
