<template>
    <div class="faq">
        <img src="/images/banners/faq-text.png" alt="faq banners">
        <div class="title">
            <h2 class="mt-8 text-3xl md:text-4xl lg:text-6xl font-light md:leading-[1.5]">Some Question And Answer, <br> <strong class=" font-semibold">Look’s here.</strong></h2>
        </div>
    </div>
</template>