<template>
    <div class="mission-vision py-section">
        <div class="container">
            <div class="grid md:grid-cols-2 md:border-t-1 md:border-b-1 items-center">
                <div class="title md:pr-15">
                    <h2 class="text-3xl lg:leading-[1.5] md:text-4xl lg:text-6xl font-light">
                        You Can <strong class=" font-semibold">Read </strong> And <strong class=" font-semibold">Write </strong>With Bunzo.
                    </h2>
                </div>
                <div class="inner md:border-l-1 md:border-r-1">
                    <div class="mission mt-4 md:mt-0 md:py-15 md:pl-15 pr-5">
                        <h4 class="mb-4">Digital Publishing</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text eve since the 1500 when an unknown printer took a galley type scrambled’s make a type specimen book. It has survived not only five centuries also the leap into electronic typesetting.</p>
                    </div>
                    <div class="vision mt-8 md:mt-0 md:py-15 md:pl-15 pr-5 md:border-t-1">
                        <h4 class="mb-4">Digital Publishing</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text eve since the 1500 when an unknown printer took a galley type scrambled’s make a type specimen book. It has survived not only five centuries also the leap into electronic typesetting.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {

    };
</script>